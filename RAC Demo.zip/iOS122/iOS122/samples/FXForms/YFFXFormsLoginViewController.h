//
//  LoginViewController.h
//  FXFormsTutorial
//
//  Created by Ben Liu on 28/11/2015.
//  Copyright © 2015 Ben Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FxForms.h"
#import "YFFXFormsLoginFXForm.h"

@interface YFFXFormsLoginViewController : FXFormViewController

@end
