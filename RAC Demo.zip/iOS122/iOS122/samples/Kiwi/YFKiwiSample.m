//
//  YFKiwiSample.m
//  iOS122
//
//  Created by 颜风 on 15/11/17.
//  Copyright © 2015年 iOS122. All rights reserved.
//

#import "YFKiwiSample.h"

@implementation YFKiwiSample

- (instancetype)init
{
    self = [super init];
    
    if (nil != self) {
        
    }
    
    return self;
}

- (void)dealloc
{
    // 可以通过这个方法,来知道对象是什么时候被释放的.
    NSLog(@"YFKiwiSample dealloc");
}
@end
