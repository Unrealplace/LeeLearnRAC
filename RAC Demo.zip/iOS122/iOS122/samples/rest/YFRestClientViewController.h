//
//  YFRestClientViewController.h
//  iOS122
//
//  Created by 颜风 on 15/10/29.
//  Copyright © 2015年 iOS122. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFRestClientViewController : UIViewController

@end
