//
//  MainViewController.h
//  TestProject
//
//  Created by 偌一茗 on 15/10/30.
//  Copyright © 2015年 boleketang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFJSPatchMainViewController : UIViewController

@end
