//
//  YFObjectionBrakes.m
//  iOS122
//
//  Created by 颜风 on 15/11/7.
//  Copyright © 2015年 iOS122. All rights reserved.
//

#import "YFObjectionBrakes.h"
#import <Objection.h>

@implementation YFObjectionBrakes
objection_register_singleton(YFObjectionBrakes)

- (instancetype)init
{
    self = [super init];
    if (nil != self) {
        
    }
    
    return self;
}
@end
