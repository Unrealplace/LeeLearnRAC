//
//  YFObjectionEngine.m
//  iOS122
//
//  Created by 颜风 on 15/11/7.
//  Copyright © 2015年 iOS122. All rights reserved.
//

#import "YFObjectionEngine.h"
#import <Objection.h>

@implementation YFObjectionEngine
objection_register(YFObjectionEngine)



@end
