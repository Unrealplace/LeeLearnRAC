//
//  YFObjectionRedBrakes.h
//  iOS122
//
//  Created by 颜风 on 15/11/8.
//  Copyright © 2015年 iOS122. All rights reserved.
//

#import "YFObjectionBrakes.h"

@interface YFObjectionRedBrakes : YFObjectionBrakes

@end
