//
//  YFJSPatchOnlineViewController.h
//  iOS122
//
//  Created by 颜风 on 15/12/7.
//  Copyright © 2015年 iOS122. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFJSPatchOnlineViewController : UIViewController

@end
