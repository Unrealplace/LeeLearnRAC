//
//  YFPatchRequest.h
//  iOS122
//
//  Created by 颜风 on 15/11/13.
//  Copyright © 2015年 iOS122. All rights reserved.
//

@interface YFPatchRequest :NSObject<YFPatchRequest>

@end
