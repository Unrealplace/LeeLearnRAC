//
//  YFMVCPostListViewController.h
//  iOS122
//
//  Created by 颜风 on 15/10/14.
//  Copyright (c) 2015年 iOS122. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YFArticleModel;

/**
 *  一个MVC的示例.
 */
@interface YFMVCPostListViewController : UIViewController
@property (nonatomic, strong) NSString * categoryName; //!< 分类名称.

@end
