//
//  YFArticleModel.m
//  iOS122
//
//  Created by 颜风 on 15/10/14.
//  Copyright (c) 2015年 iOS122. All rights reserved.
//

#import "YFArticleModel.h"

@implementation YFArticleModel

@end
