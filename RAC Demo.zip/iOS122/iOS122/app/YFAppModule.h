//
//  MCAppModule.h
//  iOS122
//
//  Created by 颜风 on 15/11/9.
//  Copyright © 2015年 iOS122. All rights reserved.
//

#import <Objection/Objection.h>

/**
 *  APP模块,内部将实现整个应用的依赖配置,也用来初始化应用的默认注入器.
 */
@interface YFAppModule : JSObjectionModule

@end
