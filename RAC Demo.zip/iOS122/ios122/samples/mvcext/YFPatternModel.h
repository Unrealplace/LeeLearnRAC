//
//  YFPatternModel.h
//  iOS122
//
//  Created by 颜风 on 15/10/13.
//  Copyright (c) 2015年 iOS122. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFPatternModel : NSObject

@end
