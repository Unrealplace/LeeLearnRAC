//
//  YFArticleCollection.m
//  iOS122
//
//  Created by 颜风 on 15/10/13.
//  Copyright (c) 2015年 iOS122. All rights reserved.
//

#import "YFArticleCollection.h"

@implementation YFArticleCollection

@end
