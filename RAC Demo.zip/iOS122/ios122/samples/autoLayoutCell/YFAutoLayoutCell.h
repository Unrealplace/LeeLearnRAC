//
//  YFAutoLayoutCell.h
//  iOS122
//
//  Created by 颜风 on 15/9/22.
//  Copyright (c) 2015年 iOS122. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YFAutoLayoutCellModel;

@interface YFAutoLayoutCell : UITableViewCell
@property (strong, nonatomic) YFAutoLayoutCellModel * model;

@end
